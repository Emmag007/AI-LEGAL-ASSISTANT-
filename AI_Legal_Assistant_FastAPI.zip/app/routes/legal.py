from fastapi import APIRouter

router = APIRouter(prefix="/legal", tags=["Legal"])

@router.get("/ask-lawyer")
async def ask_lawyer(question: str):
    return {"response": f"AI-generated response to: '{question}'" }
