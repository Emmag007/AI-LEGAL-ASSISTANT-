from fastapi import FastAPI
from app.routes.legal import router as legal_router

app = FastAPI(title="AI Legal Assistant")

# Include router
app.include_router(legal_router)

@app.get("/")
async def home():
    return {"message": "Welcome to the AI Legal Assistant!"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
